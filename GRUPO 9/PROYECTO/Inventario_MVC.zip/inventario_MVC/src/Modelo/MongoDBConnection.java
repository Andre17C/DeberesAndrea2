/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

public class MongoDBConnection {
    private MongoDatabase database;

    public MongoDBConnection() {
        try {
            // Conectar con MongoDB en localhost en el puerto 27017
            MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
            database = mongoClient.getDatabase("inventarioDB"); // Nombre de la base de datos
            System.out.println("✅ Conexión exitosa a MongoDB");
        } catch (Exception e) {
            System.out.println("❌ Error de conexión a MongoDB: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public MongoDatabase getDatabase() {
        return database;
    }
}