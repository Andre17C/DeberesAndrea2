/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Inventario;
import Modelo.Producto;
import Vista.VistaGUI;
import java.util.List;

public class Controlador_Inventario {
    private final Inventario inventario;
    private final VistaGUI vista;

    public Controlador_Inventario(Inventario inventario, VistaGUI vista) {
        this.inventario = inventario;
        this.vista = vista;
        this.vista.setControlador(this);
        actualizarVista();
    }

    private void actualizarVista() {
        List<Producto> productos = inventario.consultarProductos();
        Object[][] data = new Object[productos.size()][4];

        for (int i = 0; i < productos.size(); i++) {
            Producto p = productos.get(i);
            data[i][0] = p.getId();       // ✅ ID (sin cambios)
            data[i][1] = p.getNombre();   // ✅ Nombre (sin cambios)
            data[i][2] = p.getCantidad(); // 🔄 Ahora la cantidad está antes del precio
            data[i][3] = p.getPrecio();   // 🔄 Ahora el precio está después de la cantidad
        }

        vista.mostrarProductos(data);
        vista.mostrarTotalInventario(inventario.calcularValorTotal());
    }

    public void actualizarInventario() {
        try {
            actualizarVista();
            vista.mostrarMensaje("✅ Inventario actualizado correctamente.");
        } catch (Exception e) {
            vista.mostrarMensaje("❌ Error al actualizar el inventario: " + e.getMessage());
        }
    }

    public void agregarProducto(String nombre, double precio, int cantidad) {
        try {
            inventario.registrarProducto(new Producto(nombre, precio, cantidad));
            actualizarVista();
            vista.mostrarMensaje("✅ Producto agregado correctamente.");
        } catch (Exception e) {
            vista.mostrarMensaje("❌ Error al agregar el producto: " + e.getMessage());
        }
    }

    public void eliminarProducto(String id) {
        try {
            inventario.eliminarProducto(id);
            actualizarVista();
            vista.mostrarMensaje("✅ Producto eliminado correctamente.");
        } catch (Exception e) {
            vista.mostrarMensaje("❌ Error al eliminar el producto: " + e.getMessage());
        }
    }
}