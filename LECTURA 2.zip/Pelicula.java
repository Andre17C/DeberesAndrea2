/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.pelicula;

public class Pelicula {

    // Atributos
    String titulo;
    String genero;
    int duracion; // En minutos
    String director;

    // Constructor
    public Pelicula(String titulo, String genero, int duracion, String director) {
        this.titulo = titulo;
        this.genero = genero;
        this.duracion = duracion;
        this.director = director;
    }

    // Metodo para mostrar informacion de la pelicula
    public void mostrarInformacion() {
        System.out.println("Titulo: " + titulo);
        System.out.println("Genero: " + genero);
        System.out.println("Duracion: " + duracion + " minutos");
        System.out.println("Director: " + director);
    }

    // Metodo para calcular el tiempo restante de la pelicula
    public void tiempoRestante(int minutosVistos) {
        if (minutosVistos < duracion) {
            System.out.println("Tiempo restante: " + (duracion - minutosVistos) + " minutos");
        } else {
            System.out.println("La pelicula ya ha terminado.");
        }
    }

    // Metodo para recomendar una pelicula
    public void recomendar() {
        System.out.println("Te recomendamos ver la pelicula '" + titulo + "' si te gustan los generos de " + genero + ".");
    }

    // Metodo principal para pruebas
    public static void main(String[] args) {
        // Crear una pelicula
        Pelicula pelicula = new Pelicula("Inception", "Ciencia Ficcion", 148, "Christopher Nolan");

        // Mostrar informacion de la pelicula
        pelicula.mostrarInformacion();

        // Calcular tiempo restante
        pelicula.tiempoRestante(100);

        // Recomendar película
        pelicula.recomendar();
    }
}
