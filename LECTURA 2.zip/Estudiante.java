/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.estudiante;

public class Estudiante {

    // Atributos
    String nombre;
    int edad;
    double promedio;

    public Estudiante(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
        this.promedio = 0;
    }

    // metodo para mostrar informacion
    public void mostrarInformacion() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + edad + " años");
        System.out.println("Promedio: " + promedio);
    }

    // metodo para estudiar
    public void estudiar(int horas) {
        promedio = Math.min(10, promedio + horas * 0.5);
        System.out.println(nombre + " estudio y ahora tiene un promedio de " + promedio + ".");
    }

    // Clase interna
    public static class Profesor {
        String nombre;

        public Profesor(String nombre) {
            this.nombre = nombre;
        }

        public void enseñarEstudiante(Estudiante estudiante) {
            System.out.println(nombre + " esta enseñando a " + estudiante.nombre + ".");
        }
    }

    public static void main(String[] args) {
        Estudiante estudiante = new Estudiante("Ana", 20);
        Profesor profesor = new Profesor("Profesor Juan");

        estudiante.mostrarInformacion();
        profesor.enseñarEstudiante(estudiante);
        estudiante.estudiar(4);
    }
}

