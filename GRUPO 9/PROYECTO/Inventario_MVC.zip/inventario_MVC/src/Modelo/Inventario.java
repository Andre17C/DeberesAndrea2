/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import com.mongodb.client.*;
import org.bson.Document;
import org.bson.types.ObjectId;
import java.util.ArrayList;
import java.util.List;

public class Inventario {
    private final MongoCollection<Document> productosCollection;

    public Inventario() {
        MongoDBConnection conexion = new MongoDBConnection();
        productosCollection = conexion.getDatabase().getCollection("productos");
    }

    public void registrarProducto(Producto producto) {
        Document doc = new Document("nombre", producto.getNombre())
            .append("precio", producto.getPrecio())
            .append("cantidad", producto.getCantidad());
        productosCollection.insertOne(doc);
    }

    public void eliminarProducto(String id) {
        productosCollection.deleteOne(new Document("_id", new ObjectId(id)));
    }

    public List<Producto> consultarProductos() {
        List<Producto> productos = new ArrayList<>();
        FindIterable<Document> docs = productosCollection.find();

        for (Document doc : docs) {
            // Se obtiene el id del producto desde MongoDB
            String id = doc.getObjectId("_id").toString();
            String nombre = doc.getString("nombre");

            Object precioObj = doc.get("precio");
            double precio = (precioObj instanceof Number) ? ((Number) precioObj).doubleValue() : 0.0;

            int cantidad = doc.getInteger("cantidad");

            // Se usa el constructor que acepta id
            productos.add(new Producto(id, nombre, precio, cantidad));
        }
        return productos;
    }

    public double calcularValorTotal() {
        double total = 0;
        for (Producto p : consultarProductos()) {
            total += p.getPrecio() * p.getCantidad();
        }
        return total;
    }
}