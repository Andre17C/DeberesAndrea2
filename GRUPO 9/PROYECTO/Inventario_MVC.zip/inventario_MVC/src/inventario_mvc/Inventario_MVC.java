/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package inventario_mvc;

import Controlador.Controlador_Inventario;
import Modelo.Inventario;
import Vista.VistaGUI;

public class Inventario_MVC {
    public static void main(String[] args) {
        // Crear el modelo (Manejo de Inventario)
        Inventario modelo = new Inventario();

        // Crear la vista (Interfaz Gráfica)
        VistaGUI vista = new VistaGUI();

        // Crear el controlador y pasarle la vista y el modelo
        Controlador_Inventario controlador = new Controlador_Inventario(modelo, vista);

        // Hacer visible la ventana de la interfaz gráfica
        vista.setVisible(true);
    }
}