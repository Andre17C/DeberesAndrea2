/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.vehiculo;

public class Vehiculo {

    // Atributos
    String marca;
    String modelo;
    double velocidad;

    public Vehiculo(String marca, String modelo) {
        this.marca = marca;
        this.modelo = modelo;
        this.velocidad = 0;
    }

    // Metodo para mostrar informacion
    public void mostrarInformacion() {
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Velocidad actual: " + velocidad + " km/h");
    }

    // Metodo para acelerar
    public void acelerar(double incremento) {
        velocidad += incremento;
        System.out.println("El " + marca + " " + modelo + " ahora va a " + velocidad + " km/h.");
    }

    // Clase interna
    public static class Mecanico {
        String nombre;

        public Mecanico(String nombre) {
            this.nombre = nombre;
        }

        public void repararVehiculo(Vehiculo vehiculo) {
            System.out.println(nombre + " esta reparando el " + vehiculo.marca + " " + vehiculo.modelo + ".");
        }
    }

    public static void main(String[] args) {
        Vehiculo coche = new Vehiculo("Toyota", "FORD");
        Mecanico mecanico = new Mecanico("Santiago");

        coche.mostrarInformacion();
        mecanico.repararVehiculo(coche);
        coche.acelerar(50);
    }
}

