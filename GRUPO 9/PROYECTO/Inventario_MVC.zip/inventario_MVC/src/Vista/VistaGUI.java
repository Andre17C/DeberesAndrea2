/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import javax.swing.*;
import java.awt.*;
import Controlador.Controlador_Inventario;

public class VistaGUI extends JFrame {
    private final JTable tablaProductos;
    private final JButton btnActualizar, btnAgregar, btnEliminar;
    private final JTextField txtNombre, txtPrecio, txtCantidad;
    private final JLabel lblTotalInventario;
    private Controlador_Inventario controlador;

    public VistaGUI() {
        setTitle("Sistema de Inventario");
        setLayout(new BorderLayout());

        // *** TABLA DE PRODUCTOS ***
        tablaProductos = new JTable();
        add(new JScrollPane(tablaProductos), BorderLayout.CENTER);

        // *** PANEL DE ENTRADA DE DATOS ***
        JPanel panelEntrada = new JPanel(new GridLayout(4, 2, 5, 5));
        panelEntrada.setBorder(BorderFactory.createTitledBorder("Agregar Producto"));

        panelEntrada.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        panelEntrada.add(txtNombre);

        panelEntrada.add(new JLabel("Cantidad:"));
        txtCantidad = new JTextField();
        panelEntrada.add(txtCantidad);

        panelEntrada.add(new JLabel("Precio:"));
        txtPrecio = new JTextField();
        panelEntrada.add(txtPrecio);

        btnAgregar = new JButton("Agregar Producto");
        panelEntrada.add(btnAgregar);

        add(panelEntrada, BorderLayout.WEST);

        // *** PANEL DE BOTONES ***
        JPanel panelBotones = new JPanel();
        btnActualizar = new JButton("Actualizar Inventario");
        btnEliminar = new JButton("Eliminar Producto");

        panelBotones.add(btnActualizar);
        panelBotones.add(btnEliminar);
        add(panelBotones, BorderLayout.SOUTH);

        // *** LABEL PARA MOSTRAR EL TOTAL DEL INVENTARIO ***
        lblTotalInventario = new JLabel("Total inventario: $0.00");
        lblTotalInventario.setFont(new Font("Arial", Font.BOLD, 14));
        JPanel panelTotal = new JPanel();
        panelTotal.add(lblTotalInventario);
        add(panelTotal, BorderLayout.NORTH);

        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void setControlador(Controlador_Inventario controlador) {
        this.controlador = controlador;

        btnAgregar.addActionListener(e -> agregarProducto());
        btnActualizar.addActionListener(e -> controlador.actualizarInventario());
        btnEliminar.addActionListener(e -> eliminarProducto());
    }

    public void mostrarProductos(Object[][] data) {
        // 🔄 Se cambió el orden de las columnas
        String[] columnNames = {"ID", "Nombre", "Cantidad", "Precio"};
        tablaProductos.setModel(new javax.swing.table.DefaultTableModel(data, columnNames));
    }

    public void mostrarTotalInventario(double total) {
        lblTotalInventario.setText("Total inventario: $" + total);
    }

    public void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje);
    }

    private void agregarProducto() {
        try {
            String nombre = txtNombre.getText();
            double precio = Double.parseDouble(txtPrecio.getText());
            int cantidad = Integer.parseInt(txtCantidad.getText());

            if (nombre.isEmpty() || precio <= 0 || cantidad <= 0) {
                mostrarMensaje("❌ Error: Ingresa valores válidos.");
                return;
            }

            controlador.agregarProducto(nombre, precio, cantidad);
            txtNombre.setText("");
            txtPrecio.setText("");
            txtCantidad.setText("");
        } catch (NumberFormatException ex) {
            mostrarMensaje("❌ Error: Ingresa valores numéricos válidos.");
        }
    }

    private void eliminarProducto() {
        int filaSeleccionada = tablaProductos.getSelectedRow();
        if (filaSeleccionada == -1) {
            mostrarMensaje("❌ Error: Selecciona un producto para eliminar.");
            return;
        }

        String idProducto = tablaProductos.getValueAt(filaSeleccionada, 0).toString();
        controlador.eliminarProducto(idProducto);
    }
}