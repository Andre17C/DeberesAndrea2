/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tienda;


public class Tienda {

    // Atributos
    String nombre;
    String direccion;
    String[] productos;
    int numeroProductos;

    // Constructor
    public Tienda(String nombre, String direccion, int capacidadProductos) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.productos = new String[capacidadProductos];
        this.numeroProductos = 0;
    }

    // Metodo para agregar un producto
    public void agregarProducto(String producto) {
        if (numeroProductos < productos.length) {
            productos[numeroProductos] = producto;
            numeroProductos++;
            System.out.println("Producto agregado: " + producto);
        } else {
            System.out.println("No hay espacio para mas productos.");
        }
    }

    // Metodo para listar productos
    public void listarProductos() {
        System.out.println("Productos disponibles en " + nombre + ":");
        for (int i = 0; i < numeroProductos; i++) {
            System.out.println("- " + productos[i]);
        }
    }

    // Metodo para mostrar informacion de la tienda
    public void mostrarInformacion() {
        System.out.println("Nombre de la tienda: " + nombre);
        System.out.println("Dirección: " + direccion);
    }

    // Metodo principal para pruebas
    public static void main(String[] args) {
        // Crear una tienda
        Tienda tienda = new Tienda("Tienda El Buen Precio", "Calle Principal #123", 5);

        // Mostrar informacion de la tienda
        tienda.mostrarInformacion();

        // Agregar productos
        tienda.agregarProducto("Manzanas");
        tienda.agregarProducto("Arroz");
        tienda.agregarProducto("Leche");

        // Listar productos
        tienda.listarProductos();
    }
}
