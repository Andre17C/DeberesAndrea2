/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.animal;

public class Animal {

    // Atributos
    String especie;
    int edad;
    double peso;

    public Animal(String especie, int edad, double peso) {
        this.especie = especie;
        this.edad = edad;
        this.peso = peso;
    }

    // Metodo para mostrar informacion
    public void mostrarInformacion() {
        System.out.println("Especie: " + especie);
        System.out.println("Edad: " + edad + " años");
        System.out.println("Peso: " + peso + " kg");
    }

    // Metodo para alimentar al animal
    public void alimentar(double comida) {
        peso += comida * 0.2;
        System.out.println("Has alimentado al " + especie + ". Ahora pesa " + peso + " kg.");
    }

    // Clase interna
    public static class Cuidador {
        String nombre;

        public Cuidador(String nombre) {
            this.nombre = nombre;
        }

        public void cuidarAnimal(Animal animal) {
            System.out.println(nombre + " está cuidando a un " + animal.especie + ".");
        }
    }

    public static void main(String[] args) {
        Animal tigre = new Animal("Tigre", 5, 120.5);
        Cuidador cuidador = new Cuidador("Carlos");

        tigre.mostrarInformacion();
        cuidador.cuidarAnimal(tigre);
        tigre.alimentar(5);
    }
}
